import 'package:flutter/material.dart';
import 'package:restaurant_app_with_api/data/models/restaurant.dart';
import 'package:restaurant_app_with_api/shared/theme.dart';
import 'package:restaurant_app_with_api/ui/detail_page.dart';
import 'package:restaurant_app_with_api/widgets/ratings_stars.dart';

class RestaurantCard extends StatelessWidget {
  final Restaurant restaurant;

  const RestaurantCard({Key key, @required this.restaurant}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String baseUrlImage = "https://restaurant-api.dicoding.dev/images/medium/";
    return FlatButton(
        onPressed: () {
          Navigator.pushNamed(context, RestaurantDetail.routeName,
              arguments: restaurant.id);
        },
        child: Card(
          color: Colors.white,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                flex: 2,
                child: Container(
                  width: 120,
                  height: 118,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(8),
                        bottomLeft: Radius.circular(8),
                      ),
                      image: DecorationImage(
                          image:
                              NetworkImage(baseUrlImage + restaurant.pictureId),
                          fit: BoxFit.cover)),
                ),
              ),
              Expanded(
                flex: 3,
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Text(restaurant.name, style: titleStyle),
                      Row(children: [
                        Icon(
                          Icons.location_on,
                          size: 16,
                        ),
                        SizedBox(width: 8),
                        Text(
                          restaurant.city,
                          style: contentStyle,
                        )
                      ]),
                      RatingStars(restaurant.rating)
                    ],
                  ),
                ),
              )
            ],
          ),
        ));
  }
}
