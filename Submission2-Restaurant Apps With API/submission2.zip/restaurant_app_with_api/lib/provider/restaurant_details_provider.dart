import 'package:connectivity/connectivity.dart';
import 'package:flutter/cupertino.dart';
import 'package:restaurant_app_with_api/data/api/restaurant_api.dart';

import 'package:restaurant_app_with_api/data/models/restaurant_detail.dart';

enum ResultState { Loading, NoData, HasData, Error, NoConnection }

class RestaurantDetailProvider extends ChangeNotifier {
  final String id;
  final RestaurantService restService;

  RestaurantDetailProvider(this.restService, this.id) {
    _fetchDetailRestaurant();
  }
  ResultState _state;
  RestaurantDetailsResult _restaurantsDetailResult;
  String _message = '';

  String get message => _message;
  RestaurantDetailsResult get result => _restaurantsDetailResult;
  ResultState get state => _state;

  Future<dynamic> _fetchDetailRestaurant() async {
    try {
      var connectivity = await (Connectivity().checkConnectivity());
      if (connectivity == ConnectivityResult.none) {
        _state = ResultState.NoConnection;
        return _message = 'No Internet Connection';
      }
      _state = ResultState.Loading;
      notifyListeners();
      final restaurant = await restService.restaurantDetail(id);

      if (restaurant.restaurant == null) {
        _state = ResultState.NoData;
        notifyListeners();
        return _message = 'Empty Data';
      } else {
        _state = ResultState.HasData;
        notifyListeners();
        return _restaurantsDetailResult = restaurant;
      }
    } catch (e) {
      _state = ResultState.Error;
      notifyListeners();
      return _message = 'Errror => $e';
    }
  }
}
