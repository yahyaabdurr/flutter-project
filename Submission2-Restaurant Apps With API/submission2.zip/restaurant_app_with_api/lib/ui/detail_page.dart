import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:restaurant_app_with_api/data/api/restaurant_api.dart';
import 'package:restaurant_app_with_api/provider/restaurant_details_provider.dart';
import 'package:restaurant_app_with_api/shared/theme.dart';
import 'package:restaurant_app_with_api/widgets/menu_card.dart';
import 'package:restaurant_app_with_api/widgets/ratings_stars.dart';

class RestaurantDetail extends StatelessWidget {
  static String routeName = '/detail';
  final String id;

  RestaurantDetail(this.id);
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => RestaurantDetailProvider(RestaurantService(), id),
      child: Scaffold(
        backgroundColor: Colors.grey,
        body: Consumer<RestaurantDetailProvider>(builder: (context, rest, _) {
          if (rest.state == ResultState.Loading) {
            return Center(
              child: CircularProgressIndicator(),
            );
          } else if (rest.state == ResultState.HasData) {
            var restaurant = rest.result.restaurant;
            String urlImage =
                "https://restaurant-api.dicoding.dev/images/medium/" +
                    restaurant.pictureId;
            return SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Stack(
                    children: <Widget>[
                      SafeArea(
                        child: Container(
                          height: 300,
                          width: double.infinity,
                          decoration: BoxDecoration(
                              image: DecorationImage(
                                  image: NetworkImage(urlImage),
                                  fit: BoxFit.cover)),
                        ),
                      ),
                      SafeArea(
                        child: IconButton(
                            icon: Icon(Icons.arrow_back),
                            onPressed: () {
                              Navigator.pop(context);
                            }),
                      ),
                      SafeArea(
                        child: Container(
                          width: double.infinity,
                          margin: EdgeInsets.only(top: 280),
                          padding: EdgeInsets.symmetric(
                              vertical: 20, horizontal: 16),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                restaurant.name,
                                style: titleStyle.copyWith(fontSize: 20),
                              ),
                              RatingStars(restaurant.rating),
                              Row(
                                children: [
                                  Icon(
                                    Icons.location_on,
                                    size: 16,
                                  ),
                                  SizedBox(width: 8),
                                  Text(
                                    restaurant.city,
                                    style: contentStyle,
                                  )
                                ],
                              ),
                              Container(
                                margin: EdgeInsets.symmetric(vertical: 10),
                                child: Text(restaurant.description,
                                    style: contentStyle.copyWith(fontSize: 16)),
                              ),
                              Text(
                                "Foods",
                                style: titleStyle,
                              ),
                              Container(
                                height: 190,
                                child: Expanded(
                                  child: ListView(
                                    shrinkWrap: true,
                                    scrollDirection: Axis.horizontal,
                                    children:
                                        restaurant.menus.foods.map((food) {
                                      return MenuCard(urlImage, food.name);
                                    }).toList(),
                                  ),
                                ),
                              ),
                              Text(
                                "Drinks",
                                style: titleStyle,
                              ),
                              Container(
                                height: 190,
                                child: Expanded(
                                  child: ListView(
                                    shrinkWrap: true,
                                    scrollDirection: Axis.horizontal,
                                    children:
                                        restaurant.menus.drinks.map((drink) {
                                      return MenuCard(urlImage, drink.name);
                                    }).toList(),
                                  ),
                                ),
                              ),
                              Text(
                                "Customers Review",
                                style: titleStyle,
                              ),
                              ListView(
                                shrinkWrap: true,
                                children:
                                    restaurant.customerReviews.map((review) {
                                  return Container(
                                    margin: EdgeInsets.only(top: 10),
                                    padding: EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(8),
                                        boxShadow: [
                                          BoxShadow(
                                              spreadRadius: 3,
                                              blurRadius: 15,
                                              color: Colors.black12)
                                        ]),
                                    width: MediaQuery.of(context).size.width,
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.person,
                                          size: 50,
                                        ),
                                        Flexible(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                review.name,
                                                style: titleStyle.copyWith(
                                                    fontSize: 16),
                                              ),
                                              Text(
                                                review.review,
                                                overflow: TextOverflow.clip,
                                                style: contentStyle.copyWith(
                                                    fontSize: 14),
                                              ),
                                              Text(
                                                review.date,
                                                style: contentStyle.copyWith(
                                                    fontSize: 12),
                                              )
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  );
                                }).toList(),
                              )
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                ],
              ),
            );
          } else if (rest.state == ResultState.NoData) {
            return Center(
              child: Text(rest.message),
            );
          } else if (rest.state == ResultState.NoConnection) {
            return Center(
              child: Text(rest.message),
            );
          } else if (rest.state == ResultState.Error) {
            return Center(
              child: Text(rest.message),
            );
          } else {
            return Center(
              child: Text("Ada Masalah"),
            );
          }
        }),
      ),
    );
  }
}
