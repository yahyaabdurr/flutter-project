import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:restaurant_app_with_api/provider/restaurant_provider.dart';
import 'package:restaurant_app_with_api/data/api/restaurant_api.dart';
import 'package:restaurant_app_with_api/widgets/card_restaurant.dart';

import '../data/api/restaurant_api.dart';
import '../provider/restaurant_provider.dart';

class SearchRestaurant extends StatefulWidget {
  static String routeName = '/search';
  @override
  _SearchRestaurantState createState() => _SearchRestaurantState();
}

class _SearchRestaurantState extends State<SearchRestaurant> {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => RestaurantProvider(RestaurantService()),
      child: Scaffold(
        backgroundColor: Colors.grey,
        appBar: AppBar(
          title: Text("Restaurants Apps"),
        ),
        body: Column(children: [
          Container(
            margin: EdgeInsets.symmetric(vertical: 10),
            padding: EdgeInsets.all(5),
            decoration: BoxDecoration(
                color: Colors.white, borderRadius: BorderRadius.circular(10)),
            child: Consumer<RestaurantProvider>(
              builder: (context, provider, _) {
                return TextField(
                  decoration: InputDecoration(
                    labelText: 'Search restaurant',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide:
                          BorderSide(color: Theme.of(context).primaryColor),
                    ),
                    prefixIcon: Icon(
                      Icons.search,
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                  onChanged: (String query) {
                    provider.getRestaurant(query: query);
                  },
                );
              },
            ),
          ),
          Consumer<RestaurantProvider>(builder: (context, rest, _) {
            if (rest.state == ResultState.Loading) {
              return Center(
                child: CircularProgressIndicator(),
              );
            } else if (rest.state == ResultState.HasData) {
              return Expanded(
                child: ListView.builder(
                    itemCount: rest.result.restaurants.length,
                    itemBuilder: (context, index) {
                      var restaurant = rest.result.restaurants[index];
                      return RestaurantCard(restaurant: restaurant);
                    }),
              );
            } else if (rest.state == ResultState.NoData) {
              return Center(
                child: Text(rest.message),
              );
            } else if (rest.state == ResultState.NoConnection) {
              return Center(
                child: Text(rest.message),
              );
            } else if (rest.state == ResultState.Error) {
              return Center(
                child: Text(rest.message),
              );
            } else {
              return Center(
                child: Text("Ada Masalah"),
              );
            }
          }),
        ]),
      ),
    );
  }
}
