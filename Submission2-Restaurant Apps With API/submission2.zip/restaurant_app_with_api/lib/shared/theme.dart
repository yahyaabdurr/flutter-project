import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supercharged/supercharged.dart';

Color mainColor = 'e74c3c'.toColor();
Color greyColor = 'bdc3c7'.toColor();

TextStyle contentStyle =
    GoogleFonts.poppins(fontWeight: FontWeight.w300, fontSize: 16);
TextStyle titleStyle =
    GoogleFonts.poppins(fontWeight: FontWeight.w500, fontSize: 20);
