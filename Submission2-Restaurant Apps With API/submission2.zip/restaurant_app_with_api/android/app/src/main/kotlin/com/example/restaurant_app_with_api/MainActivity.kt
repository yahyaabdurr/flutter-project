package com.example.restaurant_app_with_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
