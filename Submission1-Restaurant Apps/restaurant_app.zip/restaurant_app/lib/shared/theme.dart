part of 'shared.dart';

Color mainColor = 'e74c3c'.toColor();
Color greyColor = 'bdc3c7'.toColor();
TextStyle titleStyle =
    GoogleFonts.poppins(fontWeight: FontWeight.w500, fontSize: 20);

TextStyle contentStyle =
    GoogleFonts.poppins(fontWeight: FontWeight.w300, fontSize: 16);
