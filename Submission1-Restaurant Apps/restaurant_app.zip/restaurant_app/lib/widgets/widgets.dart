import 'package:flutter/material.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'package:restaurant_app/models/food.dart';
import 'package:restaurant_app/shared/shared.dart';

part 'custom_card.dart';
part 'ratings_stars.dart';
