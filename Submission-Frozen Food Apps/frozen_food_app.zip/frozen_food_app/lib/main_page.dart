import 'package:flutter/material.dart';
import 'package:frozen_food_app/detail_page.dart';
import 'package:frozen_food_app/models/frozen_food.dart';
import 'package:frozen_food_app/shared/shared.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';

class MainPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: greyColor,
      appBar: AppBar(
        title: Text("Risollaku Apps", style: TextStyle(color: Colors.black)),
        backgroundColor: mainColor,
      ),
      body: ListView(
          children: listRisolles.map((risol) {
        return FlatButton(
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) {
              return DetailPage(risol);
            }));
          },
          child: Card(
            color: Colors.white,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  flex: 1,
                  child: Container(
                    width: 100,
                    height: 80,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(8),
                          bottomRight: Radius.circular(8),
                        ),
                        image: DecorationImage(
                            image: AssetImage(risol.imageUrl),
                            fit: BoxFit.cover)),
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        Text(risol.name,
                            style: GoogleFonts.poppins(
                                fontWeight: FontWeight.w500, fontSize: 16)),
                        SizedBox(
                          height: 10,
                        ),
                        Text(
                            NumberFormat.currency(
                                    locale: 'id-ID',
                                    symbol: 'Rp ',
                                    decimalDigits: 2)
                                .format(risol.price),
                            style: GoogleFonts.poppins(
                                    fontWeight: FontWeight.w500, fontSize: 14)
                                .copyWith(color: greyColor))
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        );
      }).toList()),
    );
  }
}

var listRisolles = [
  FrozenFood(
      "Risol Smoked Beef Mayo",
      25000,
      "Risol Smoked Beef Mayo atau sering disebut risol pedas merupakan salah satu variasi dari risoles biasa atau risoles klasik. Jika risoles biasa pada umumnya berisi sayuran atau bahan tradisional lainnya, maka cemilan yang satu ini bisa dibilang sedikit modern. Isian yang digunakan adalah paduan beberapa bahan yang dilengkapi dengan saus mayonaise untuk mendapatkan cita rasa gurih.",
      'assets/frozen_food0.jpeg',
      ratings: 5),
  FrozenFood(
      "Risol Smoked Beef Mayo",
      25000,
      "Risol Smoked Beef Mayo atau sering disebut risol mayo merupakan salah satu variasi dari risoles biasa atau risoles klasik. Jika risoles biasa pada umumnya berisi sayuran atau bahan tradisional lainnya, maka cemilan yang satu ini bisa dibilang sedikit modern. Isian yang digunakan adalah paduan beberapa bahan yang dilengkapi dengan saus mayonaise untuk mendapatkan cita rasa gurih.",
      'assets/frozen_food1.jpeg',
      ratings: 4.8),
  FrozenFood(
      "Risol Ragout",
      25000,
      "Risol Ragout merupakan salah satu variasi dari risoles biasa atau risoles klasik. Jika risoles biasa pada umumnya berisi sayuran atau bahan tradisional lainnya, maka cemilan yang satu ini bisa dibilang sedikit modern. Isian yang digunakan adalah paduan beberapa bahan yang dilengkapi dengan saus mayonaise untuk mendapatkan cita rasa gurih.",
      'assets/frozen_food2.jpeg',
      ratings: 4.9),
  FrozenFood(
      "Risol Keju",
      25000,
      "Risol Keju atau sering disebut risol mayo keju merupakan salah satu variasi dari risoles biasa atau risoles klasik. Jika risoles biasa pada umumnya berisi sayuran atau bahan tradisional lainnya, maka cemilan yang satu ini bisa dibilang sedikit modern. Isian yang digunakan adalah paduan beberapa bahan yang dilengkapi dengan saus mayonaise untuk mendapatkan cita rasa gurih.",
      'assets/frozen_food3.jpeg',
      ratings: 4.9),
  FrozenFood(
      "Risol Smoked Beef Spagetti",
      25000,
      "Risol Smoked Beef Spaggeti atau sering disebut risol mayo Spagetti merupakan salah satu variasi dari risoles biasa atau risoles klasik. Jika risoles biasa pada umumnya berisi sayuran atau bahan tradisional lainnya, maka cemilan yang satu ini bisa dibilang sedikit modern. Isian yang digunakan adalah paduan beberapa bahan yang dilengkapi dengan saus mayonaise untuk mendapatkan cita rasa gurih.",
      'assets/frozen_food4.jpeg',
      ratings: 4.5),
  FrozenFood(
      "Risol Smoked Beef Ayam",
      25000,
      "Risol Smoked Beef Ayam atau sering disebut risol Ayam Spagetti merupakan salah satu variasi dari risoles biasa atau risoles klasik. Jika risoles biasa pada umumnya berisi sayuran atau bahan tradisional lainnya, maka cemilan yang satu ini bisa dibilang sedikit modern. Isian yang digunakan adalah paduan beberapa bahan yang dilengkapi dengan saus mayonaise untuk mendapatkan cita rasa gurih.",
      'assets/frozen_food5.jpeg',
      ratings: 4.6),
  FrozenFood(
      "Risolles Sapi",
      25000,
      "Risolles Sapi merupakan salah satu variasi dari risoles biasa atau risoles klasik. Jika risoles biasa pada umumnya berisi sayuran atau bahan tradisional lainnya, maka cemilan yang satu ini bisa dibilang sedikit modern. Isian yang digunakan adalah paduan beberapa bahan yang dilengkapi dengan saus mayonaise untuk mendapatkan cita rasa gurih.",
      'assets/frozen_food6.jpeg',
      ratings: 4.6),
];
