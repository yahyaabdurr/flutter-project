class FrozenFood {
  String name;
  double price;
  double ratings;
  String description;
  String imageUrl;
  String testimoni;

  FrozenFood(this.name, this.price, this.description, this.imageUrl,
      {this.ratings = 4.5, this.testimoni = "Belum ada testimoni"});
}
