part of 'shared.dart';

Color mainColor = "FFC700".toColor();
Color greyColor = "7f8c8d".toColor();

TextStyle titleStyle =
    GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w500);
TextStyle contentStyle = GoogleFonts.poppins(
    fontSize: 16, fontWeight: FontWeight.w300, color: greyColor);
