import 'package:flutter/material.dart';
import 'package:frozen_food_app/shared/shared.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';

part 'rating_stars.dart';
