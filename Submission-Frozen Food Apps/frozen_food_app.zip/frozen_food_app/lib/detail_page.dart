import 'package:flutter/material.dart';
import 'package:frozen_food_app/models/frozen_food.dart';
import 'package:frozen_food_app/shared/shared.dart';
import 'package:frozen_food_app/shared/widgets/widgets.dart';
import 'package:intl/intl.dart';

class DetailPage extends StatelessWidget {
  final FrozenFood food;
  DetailPage(this.food);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Stack(
              children: <Widget>[
                SafeArea(
                  child: Container(
                    height: 300,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        image: DecorationImage(
                            image: AssetImage(food.imageUrl),
                            fit: BoxFit.cover)),
                  ),
                ),
                SafeArea(
                  child: IconButton(
                      icon: Icon(Icons.arrow_back),
                      onPressed: () {
                        Navigator.pop(context);
                      }),
                ),
                SafeArea(
                  child: Container(
                    width: double.infinity,
                    margin: EdgeInsets.only(top: 280),
                    padding: EdgeInsets.symmetric(vertical: 20, horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20),
                      ),
                    ),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  food.name,
                                  style: titleStyle.copyWith(fontSize: 20),
                                ),
                                RatingStars(food.ratings)
                              ],
                            ),
                            CartButton()
                          ],
                        ),
                        Container(
                          margin: EdgeInsets.symmetric(vertical: 10),
                          child: Text(food.description,
                              style: contentStyle.copyWith(fontSize: 16)),
                        ),
                        SizedBox(
                          width: double.infinity,
                          height: 20,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("Price", style: titleStyle),
                                Text(
                                    NumberFormat.currency(
                                            locale: 'id-ID',
                                            symbol: 'Rp ',
                                            decimalDigits: 2)
                                        .format(food.price),
                                    style:
                                        titleStyle.copyWith(color: greyColor))
                              ],
                            ),
                            Container(
                              height: 45,
                              width: 200,
                              decoration: BoxDecoration(
                                  color: mainColor,
                                  borderRadius: BorderRadius.circular(8)),
                              child: Center(
                                child: Text(
                                  "Order Now",
                                  style: titleStyle,
                                ),
                              ),
                            ),
                          ],
                        )
                      ],
                    ),
                  ),
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class CartButton extends StatefulWidget {
  @override
  _CartButtonState createState() => _CartButtonState();
}

class _CartButtonState extends State<CartButton> {
  bool isCartAdded = false;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          isCartAdded = true;
        });
      },
      child: Container(
        height: 45,
        width: 45,
        decoration: BoxDecoration(
            image: DecorationImage(
                image: (isCartAdded)
                    ? AssetImage('assets/btn_add_cart_success.png')
                    : AssetImage('assets/btn_add_cart.png'))),
      ),
    );
  }
}
